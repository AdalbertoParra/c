package edu.citytech.javareview.utility;
import java.io.File;
import java.util.function.Consumer;

public class FileUtility {
    public final  Consumer<String> dir = this::getAllFiles;
    public final  Consumer<String> ls = this::getAllFiles;
    public Consumer<File> consumer = System.out::println;

    public FileUtility(){}

    public FileUtility(Consumer<File> consumer) {
        this.consumer = consumer;
    }

    private void getAllFiles(String directory){
        File folder = new File(directory);
        File[] listOfFiles = folder.listFiles();

        for(File file : listOfFiles){
            if(file.isFile()){
                consumer.accept(file);
                //System.out.println(file.getName());
            }
        }
    }
}
    // public static void booboo(File x ){
    //     System.out.println(x.getName().toUpperCase() + " A consumer just takes");
    // }

    // public static void main(String[] args) {
    //     var x = new FileUtility(FileUtility::booboo);

    //     //x.dir.accept(null);
    //     x.dir.accept("\\Users\\Owner\\Documents\\Fall 2024\\Data Structures\\Session 4\\cst3650\\cst3650\\holding-area");
    //     System.out.println("-".repeat(100));
    //     x.dir.accept("\\data\\excel");
    //     System.out.println("Adalberto Parra October 10 2:47 ");
    // }
//}
