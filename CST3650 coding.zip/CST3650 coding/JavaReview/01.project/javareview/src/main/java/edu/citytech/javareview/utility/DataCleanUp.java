package edu.citytech.javareview.utility;

import java.util.function.Function;

public class DataCleanUp {

    public static Function<String, Float> cleanUpPrice = e -> {
        String cleanData = e.replaceAll("\\$", "").replaceAll(",","");
        return Float.parseFloat(cleanData);
    };

    public static Function<String, Float> cleanUpMarketCap = e -> {
        String cleanData = e.toUpperCase().replaceAll("\\$", "").replace("B","").replaceAll("T","")
                            .replaceAll("M","").replaceAll(",","");
        float number = Float.parseFloat(cleanData);

        if(e.contains("T"))
            number = number*1_000;
        else if (e.contains("M"))
            number = number*1_000;
        else if (number > 1_000_000_000)
            number = number / 1_000_000_000;

        //return Float.parseFloat(cleanData);
        return number;
    };

    public static Function<String, Float> cleanUpPercentage = e -> {
        String cleanData = e.replaceAll("%","");
        return Float.parseFloat(cleanData)/100;
    };

    public static Function<String, String> cleanMonth = e -> {
        String cleanData = e.replaceAll(",","|").replaceAll(" ","")
                            .replaceAll("1-12","1,2,3,4,5,6,7,8,9,10,11,12")
                            .replaceAll(",","|");
        return cleanData;
    };

    public static Function<String, String> cleanSource = e -> {
        String cleanData = e.toLowerCase().replaceAll(",","").replace(".html","")
                            .replace("cst3650","")
                            .replace("_","")
                            .replace("-","");
        return cleanData;
    };
}
