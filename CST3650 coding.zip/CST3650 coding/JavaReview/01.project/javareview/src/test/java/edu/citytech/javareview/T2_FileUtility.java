package edu.citytech.javareview;

import org.junit.jupiter.api.Test;
import edu.citytech.javareview.utility.FileUtility;
import java.io.File;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class T2_FileUtility {
 
    public static void fileLogic(File file ){
        //System.out.println(file.getName());

        try {
            Document doc = Jsoup.parse(file);
            Elements elements = doc.select("table tr");
            
            int lineNO = 1;
            for (var e : elements) {
                if (lineNO > 1)
                System.out.println(e.text());
                else 
                 lineNO++;
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    @Test
    void t1() {
       var x = new FileUtility(T2_FileUtility::fileLogic);
        x.dir.accept("\\Users\\Owner\\Documents\\Fall 2024\\Data Structures\\Session 5\\good-data\\good");
        
        
    }
}
