package edu.citytech.javareview;

import java.util.function.Consumer;

import org.junit.jupiter.api.Test;

import edu.citytech.javareview.dao.StockDAO;
import edu.citytech.javareview.dto.Stock;

public class T3_StockDAO {

   //Developer: Adalberto Parra Salas

    @Test
    void t1(){
        Consumer<Stock> consumer = System.out::println;
        var dao = new StockDAO(consumer);
        dao.query();
        System.out.println("Adalberto, Parra " + new java.util.Date());
    }
    @Test
    void t2(){

    }
}
