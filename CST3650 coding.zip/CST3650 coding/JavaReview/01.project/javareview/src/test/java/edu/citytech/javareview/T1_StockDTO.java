package edu.citytech.javareview;

import org.jsoup.Jsoup;
import org.jsoup.internal.Functions;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.assertEquals;
import edu.citytech.javareview.dto.*;
import java.util.function.*;

import static edu.citytech.javareview.utility.DataCleanUp.*;
//Author Adalberto Parra 
public class T1_StockDTO {

    String html = """
        <table>
            <tr>
                <td>IBM</td>
                <td> $200.27 </td>
                <td>$182.81B</td>
                <td>3.37%</td>
                <td>2,5,8,11</td>
            </tr>
        </table>
            """;

        Document doc = Jsoup.parse(html);
        Elements elements = doc.select("td");
        

    @Test
    void t1() {

        Stock stock = new Stock();
        stock.setSymbol( elements.get(0).text() );    
        var expected = "IBM";
        var actual = stock.getSymbol();
        assertEquals(expected, actual);
        
        System.out.println("1st Test Parra, Adalberto " + new Date());
        
}


    @Test
    @DisplayName("Test for price")
    void t2() {

        Document doc = Jsoup.parse(html);
        Elements elements = doc.select("td");
        Stock stock = new Stock();
        float price = cleanUpPrice.apply(elements.get(1).text());
        stock.setPrice(price);
        var expected = 200.27f;
        var actual = stock.getPrice();
        assertEquals(expected, actual);

        System.out.println("2nd Test Parra, Adalberto " + new Date());
}

    @Test
    @DisplayName("Test for MarketCap")
    void t3() {

        Document doc = Jsoup.parse(html);
        Elements elements = doc.select("td");
        Stock stock = new Stock();
        float marketCap = cleanUpMarketCap.apply(elements.get(2).text());
        stock.setMarhetCapInBillion(marketCap);
        var expected = 182.81f;
        var actual = stock.getMarhetCapInBillion();
        assertEquals(expected, actual);

        System.out.println("3rd Test Parra, Adalberto " + new Date());
}
}
//     @DisplayName("Test for price")
//     void t4() {

//         Document doc = Jsoup.parse(html);
//         Elements elements = doc.select("td");
//         Stock stock = new Stock();
//         float price = cleanUpPrice.apply(elements.get(3).text());
//         stock.setPrice(price);
//         var expected = 200.27f;
//         var actual = stock.getPrice();
//         assertEquals(expected, actual);

//         System.out.println("4th Test Parra, Adalberto " + new Date());
 
